from roles.intern import Intern
from roles.hr import HR
from roles.admin import Admin

def main():
    print("=== Role-Based Logging System ===")
    name = input("Enter your name: ")

    print("\nChoose Role:")
    print("1. Intern")
    print("2. HR")
    print("3. Admin")

    choice = input("Enter choice (1-3): ")

    if choice == "1":
        user = Intern(name)
    elif choice == "2":
        user = HR(name)
    elif choice == "3":
        user = Admin(name)
    else:
        print("Invalid option.")
        return

    user.login()

    while True:
        print("\nChoose Action:")
        print("1. Perform Task")
        print("2. Exit")
        action = input("Enter action: ")

        if action == "1":
            user.perform_task()
        elif action == "2":
            print("Goodbye!")
            break
        else:
            print("Invalid action.")

if __name__ == "__main__":
    main()
