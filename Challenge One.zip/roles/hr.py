from logger import RoleLogger
from roles.base_user import BaseUser

class HR(BaseUser):
    def login(self):
        with RoleLogger('hr.log') as logger:
            logger.log(f"{self.name} (HR) logged in.")
        print(f"{self.name} logged in as HR.")

    def perform_task(self):
        with RoleLogger('hr.log') as logger:
            logger.log(f"{self.name} scheduled an interview.")
        print(f"{self.name} scheduled an interview.")
