from logger import RoleLogger
from roles.base_user import BaseUser

class Intern(BaseUser):
    def login(self):
        with RoleLogger('intern.log') as logger:
            logger.log(f"{self.name} (Intern) logged in.")
        print(f"{self.name} logged in as Intern.")

    def perform_task(self):
        with RoleLogger('intern.log') as logger:
            logger.log(f"{self.name} completed a coding task.")
        print(f"{self.name} completed a coding task.")
