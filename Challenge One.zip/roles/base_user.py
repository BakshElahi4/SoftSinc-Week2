class BaseUser:
    def __init__(self, name):
        self.name = name

    def login(self):
        raise NotImplementedError

    def perform_task(self):
        raise NotImplementedError
