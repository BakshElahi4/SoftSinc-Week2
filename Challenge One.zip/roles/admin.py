from logger import RoleLogger
from roles.base_user import BaseUser

class Admin(BaseUser):
    def login(self):
        with RoleLogger('admin.log') as logger:
            logger.log(f"{self.name} (Admin) logged in.")
        print(f"{self.name} logged in as Admin.")

    def perform_task(self):
        with RoleLogger('admin.log') as logger:
            logger.log(f"{self.name} reviewed system reports.")
        print(f"{self.name} reviewed system reports.")
