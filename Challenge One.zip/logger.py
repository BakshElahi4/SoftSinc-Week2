from datetime import datetime

class RoleLogger:
    def __init__(self, filename):
        self.filename = filename

    def __enter__(self):
        self.file = open(self.filename, 'a')
        return self

    def log(self, message):
        timestamp = datetime.now().strftime("[%Y-%m-%d %H:%M:%S]")
        self.file.write(f"{timestamp} {message}\n")

    def __exit__(self, exc_type, exc_value, traceback):
        self.file.close()
