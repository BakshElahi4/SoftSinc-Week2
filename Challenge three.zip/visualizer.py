import matplotlib.pyplot as plt
import seaborn as sns
import os
import pandas as pd
from datetime import datetime

# Create plots directory if it doesn't exist
os.makedirs("plots", exist_ok=True)

def timestamped_filename(base_name):
    time_str = datetime.now().strftime("%Y%m%d_%H%M%S")
    return f"plots/{base_name}_{time_str}.png"

def visualize_data(df):
    # 1. Bar Plot: Device Type Counts
    plt.figure(figsize=(10, 6))
    device_counts = df["Device Type"].value_counts()
    sns.barplot(x=device_counts.index, y=device_counts.values, palette="viridis")
    plt.title("Device Type Counts")
    plt.xticks(rotation=45)
    plt.tight_layout()
    bar_path = timestamped_filename("bar_plot_device_counts")
    plt.savefig(bar_path)
    plt.close()

    # 2. Line Plot: Power Consumption vs Usage Duration
    plt.figure(figsize=(10, 6))
    plt.plot(df["Usage Duration (minutes)"], df["Power Consumption (W)"], marker='o', linestyle='-', color='green')
    plt.title("Power Consumption vs. Usage Duration")
    plt.xlabel("Usage Duration (minutes)")
    plt.ylabel("Power Consumption (W)")
    plt.grid(True)
    plt.tight_layout()
    line_path = timestamped_filename("line_plot_power_vs_usage")
    plt.savefig(line_path)
    plt.close()

    # 3. Histogram: Energy Cost Distribution
    plt.figure(figsize=(10, 6))
    sns.histplot(df["Energy Cost ($)"], bins=20, kde=True, color='skyblue')
    plt.title("Energy Cost Distribution")
    plt.xlabel("Energy Cost ($)")
    plt.tight_layout()
    hist_path = timestamped_filename("hist_energy_cost")
    plt.savefig(hist_path)
    plt.close()

    print(f"✅ Plots saved to:\n- {bar_path}\n- {line_path}\n- {hist_path}")
