import pandas as pd
import numpy as np

def clean_data(df):
    log = []
    df_clean = df.copy()

    # Convert object columns that look like dates
    for col in df_clean.select_dtypes(include='object').columns:
        sample = df_clean[col].dropna().astype(str).head(10)
        if sample.str.contains(r"\d{1,2}/\d{1,2}/\d{2,4}").any():
            before = df_clean[col].isna().sum()
            df_clean[col] = pd.to_datetime(df_clean[col], errors='coerce')
            after = df_clean[col].isna().sum()
            if after != before:
                log.append(f"Converted '{col}' to datetime. {after - before} NaT entries added.")

    # Try converting object columns to numeric
    for col in df_clean.columns:
        if df_clean[col].dtype == 'object':
            before = df_clean[col].isna().sum()
            df_clean[col] = pd.to_numeric(df_clean[col], errors='coerce')
            after = df_clean[col].isna().sum()
            if after > before:
                log.append(f"Converted '{col}' to numeric. {after - before} new NaN entries.")

    # Fill missing values based on column type
    for col in df_clean.columns:
        missing = df_clean[col].isna().sum()
        if missing > 0:
            if df_clean[col].dtype == 'object':
                mode = df_clean[col].mode(dropna=True)
                fill_val = mode[0] if not mode.empty else "Unknown"
                df_clean[col].fillna(fill_val, inplace=True)
                log.append(f"Filled {missing} missing in '{col}' with {fill_val}")
            elif np.issubdtype(df_clean[col].dtype, np.number):
                median = df_clean[col].median()
                df_clean[col].fillna(median, inplace=True)
                log.append(f"Filled {missing} missing in '{col}' with median: {median}")
            elif np.issubdtype(df_clean[col].dtype, np.datetime64):
                mode = df_clean[col].mode()
                if not mode.empty:
                    df_clean[col].fillna(mode[0], inplace=True)
                    log.append(f"Filled {missing} missing in datetime '{col}' with: {mode[0]}")

    log.append(f"Final cleaned shape: {df_clean.shape}")
    return df_clean, log
