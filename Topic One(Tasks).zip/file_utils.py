# file_utils.py

def write_to_file(filename, content):
    with open(filename, 'a') as f:
        f.write(content + '\n')

def read_from_file(filename):
    with open(filename, 'r') as f:
        return f.readlines()
