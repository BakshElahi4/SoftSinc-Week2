# main.py

from file_utils import write_to_file
from datetime import datetime

class Logger:
    def __init__(self, filename='logs.txt'):
        self.filename = filename

    def log(self, message):
        timestamp = datetime.now().strftime("[%Y-%m-%d %H:%M:%S]")
        with open(self.filename, 'a') as f:
            f.write(f"{timestamp} {message}\n")


# === Base User Class ===
class User:
    def __init__(self, name):
        self.name = name
        self.logger = Logger()

    def login(self):
        msg = f"{self.name} logged in as User."
        self.logger.log(msg)
        print(msg)

    def send_message(self, msg):
        log_msg = f"{self.name} (User) sent message: {msg}"
        self.logger.log(log_msg)
        print(log_msg)


# === Derived Roles ===
class Intern(User):
    def login(self):
        msg = f"{self.name} logged in as Intern."
        self.logger.log(msg)
        print(msg)

class Mentor(User):
    def login(self):
        msg = f"{self.name} logged in as Mentor."
        self.logger.log(msg)
        print(msg)


# === Composed Roles ===
class Admin:
    def __init__(self):
        self.logger = Logger()

    def manage_users(self):
        msg = "Admin managing users."
        self.logger.log(msg)
        print(msg)

class HR:
    def __init__(self):
        self.logger = Logger()

    def schedule_interview(self):
        msg = "HR scheduling interview."
        self.logger.log(msg)
        print(msg)


# === User with Composed Role ===
class ComposedUser(User):
    def __init__(self, name, role_obj=None):
        super().__init__(name)
        self.role_obj = role_obj

    def perform_role(self):
        if self.role_obj:
            if isinstance(self.role_obj, Admin):
                self.role_obj.manage_users()
            elif isinstance(self.role_obj, HR):
                self.role_obj.schedule_interview()


# === CLI Application ===

def main():
    print("Welcome to the Role-Based System\n")

    name = input("Enter your name: ")
    print("Choose your role:")
    print("1. Intern")
    print("2. Mentor")
    print("3. Admin")
    print("4. HR")
    choice = input("Enter option (1-4): ")

    if choice == "1":
        user = Intern(name)
    elif choice == "2":
        user = Mentor(name)
    elif choice == "3":
        user = ComposedUser(name, Admin())
    elif choice == "4":
        user = ComposedUser(name, HR())
    else:
        print("Invalid choice. Exiting.")
        return

    # === Login and actions ===
    user.login()

    while True:
        print("\nChoose an action:")
        print("1. Send Message")
        if isinstance(user, ComposedUser):
            print("2. Perform Role Task")
            print("3. Exit")
        else:
            print("2. Exit")

        action = input("Enter action number: ")

        if action == "1":
            msg = input("Enter message: ")
            user.send_message(msg)

        elif action == "2" and isinstance(user, ComposedUser):
            user.perform_role()

        elif (action == "2" and not isinstance(user, ComposedUser)) or (action == "3" and isinstance(user, ComposedUser)):
            print("Goodbye!")
            break

        else:
            print("Invalid option.")


if __name__ == "__main__":
    main()
