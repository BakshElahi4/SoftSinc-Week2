import os
import pandas as pd
from datetime import datetime

def generate_summary(df, file_path="D:\Softsinc\Week two\smart_home_energy_consumption.csv"):
    # Create summary folder if it doesn't exist
    os.makedirs("summary", exist_ok=True)

    # Get current timestamp
    timestamp = datetime.now().strftime("%Y%m%d_%H%M")
    
    # Summary components
    file_name = os.path.basename(file_path)
    shape_info = f"Shape of dataset: {df.shape}"
    column_types = df.dtypes.to_string()
    basic_stats = df.describe(include='all').transpose()
    
    # Prepare text summary
    summary_text = f"""Summary Report
Timestamp: {timestamp}
File Name: {file_name}

{shape_info}

Column Types:
{column_types}

Basic Statistics:
{basic_stats.to_string()}
"""

    # Save to .txt
    txt_path = f"summary/summary_{timestamp}.txt"
    with open(txt_path, "w") as f:
        f.write(summary_text)

    # Save basic stats to .csv
    csv_path = f"summary/summary_{timestamp}.csv"
    basic_stats.to_csv(csv_path)

    print(f"Summary saved to:\n- {txt_path}\n- {csv_path}")
