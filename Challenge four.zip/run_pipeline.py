import pandas as pd
from scripts.cleaner import clean_data
from scripts.visualizer import visualize_data
from scripts.summarizer import generate_summary

def run_pipeline():
    print("Loading dataset...")
    df = pd.read_csv("data/smart_home_energy_consumption.csv")

    print("Cleaning data...")
    cleaned_df, log = clean_data(df)
    for line in log:
        print("🔧", line)

    cleaned_df.to_csv("data/cleaned_data.csv", index=False)
    print("Cleaned data saved.")

    print("Visualizing data...")
    visualize_data(cleaned_df)
    print("Visualizations saved to /plots")

    print("Generating summary...")
    generate_summary(cleaned_df)
    print("Summary saved to /summary")

if __name__ == "__main__":
    run_pipeline()
