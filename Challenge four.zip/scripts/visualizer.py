import matplotlib.pyplot as plt
import seaborn as sns
import os
from datetime import datetime

def visualize_data(df):
    os.makedirs("plots", exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M")

    # Bar Plot: Count by Device Type
    plt.figure(figsize=(10, 5))
    df["Device Type"].value_counts().plot(kind='bar', title="Device Type Counts")
    plt.tight_layout()
    plt.savefig(f"plots/barplot_{timestamp}.png")

    # Line Chart: Power Consumption by Usage Duration
    plt.figure(figsize=(10, 5))
    df_sorted = df.sort_values("Usage Duration (minutes)")
    plt.plot(df_sorted["Usage Duration (minutes)"], df_sorted["Power Consumption (W)"], marker='o')
    plt.title("Power Consumption vs Usage Duration")
    plt.xlabel("Usage Duration (minutes)")
    plt.ylabel("Power Consumption (W)")
    plt.tight_layout()
    plt.savefig(f"plots/linechart_{timestamp}.png")

    # Heatmap
    plt.figure(figsize=(10, 6))
    sns.heatmap(df.select_dtypes(include='number').corr(), annot=True, cmap="coolwarm")
    plt.title("Correlation Heatmap")
    plt.tight_layout()
    plt.savefig(f"plots/heatmap_{timestamp}.png")
