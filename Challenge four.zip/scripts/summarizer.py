import os
from datetime import datetime

def generate_summary(df, file_path="data/cleaned_data.csv"):
    os.makedirs("summary", exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M")

    shape_info = f"Shape: {df.shape}"
    types_info = df.dtypes.to_string()
    stats = df.describe(include='all').transpose()

    text_summary = f"""Summary Report - {timestamp}
File: {file_path}

{shape_info}

Column Types:
{types_info}

Basic Stats:
{stats.to_string()}
"""

    with open(f"summary/summary_{timestamp}.txt", "w") as f:
        f.write(text_summary)

    stats.to_csv(f"summary/summary_{timestamp}.csv")
