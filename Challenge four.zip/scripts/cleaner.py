import pandas as pd

def clean_data(df):
    log = []

    # Detect and handle missing values
    missing = df.isnull().sum()
    log.append("Missing values per column:\n" + str(missing))

    df = df.dropna()
    log.append("Dropped rows with missing values.")

    # Fix data types
    try:
        df["Timestamp"] = pd.to_datetime(df["Timestamp"])
        df["Temperature (°C)"] = pd.to_numeric(df["Temperature (°C)"], errors='coerce')
        df["Humidity (%)"] = pd.to_numeric(df["Humidity (%)"], errors='coerce')
        df["Power Consumption (W)"] = pd.to_numeric(df["Power Consumption (W)"], errors='coerce')
        df["Usage Duration (minutes)"] = pd.to_numeric(df["Usage Duration (minutes)"], errors='coerce')
        df["Energy Cost ($)"] = pd.to_numeric(df["Energy Cost ($)"], errors='coerce')
        log.append("Converted data types successfully.")
    except Exception as e:
        log.append(f"Error in type conversion: {e}")

    return df, log
